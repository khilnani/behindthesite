//
//  RearMasterTableViewController.h
//  RevealControllerProject3
//
//  Created by Joan on 30/12/12.
//
//

#import <UIKit/UIKit.h>

@interface RearMasterTableViewController : UITableViewController

@end
