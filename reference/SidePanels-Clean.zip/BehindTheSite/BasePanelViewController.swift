//
//  BasePanelViewController.swift
//  BehindTheSite
//
//  Created by Nik Khilnani on 2/17/15.
//  Copyright (c) 2015 Nik Khilnani. All rights reserved.
//

protocol BasePanelViewController {
    
}